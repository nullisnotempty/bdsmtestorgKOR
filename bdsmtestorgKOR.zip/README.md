# bdsmtestorgKOR
bdsmtest.org를 한국어로 번역하는 크롬 확장 플러그인입니다.
